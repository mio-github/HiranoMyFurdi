class User {
  final String id;
  final String name;
  final String memberId;
  final DateTime memberSince;
  final int totalVisits;
  final int totalBadges;

  User({
    required this.id,
    required this.name,
    required this.memberId,
    required this.memberSince,
    required this.totalVisits,
    required this.totalBadges,
  });

  static User mockUser = User(
    id: '1',
    name: 'さくら',
    memberId: 'FUR-2024-0123',
    memberSince: DateTime.now().subtract(const Duration(days: 90)),
    totalVisits: 52,
    totalBadges: 15,
  );
}
