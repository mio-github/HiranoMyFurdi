class HealthData {
  final double currentWeight;
  final double weightChange;
  final double bodyFatPercentage;
  final double muscleMass;
  final double bmi;
  final List<double> weeklyWeights;

  HealthData({
    required this.currentWeight,
    required this.weightChange,
    required this.bodyFatPercentage,
    required this.muscleMass,
    required this.bmi,
    required this.weeklyWeights,
  });

  bool get isWeightDecreasing => weightChange < 0;

  static HealthData mockHealthData = HealthData(
    currentWeight: 54.2,
    weightChange: -0.3,
    bodyFatPercentage: 24.5,
    muscleMass: 38.2,
    bmi: 21.2,
    weeklyWeights: [55.1, 54.9, 54.8, 54.6, 54.5, 54.3, 54.2],
  );

  static List<HealthRecord> mockWeeklyData = [
    HealthRecord(
      date: DateTime.now().subtract(const Duration(days: 6)),
      weight: 55.1,
    ),
    HealthRecord(
      date: DateTime.now().subtract(const Duration(days: 5)),
      weight: 54.9,
    ),
    HealthRecord(
      date: DateTime.now().subtract(const Duration(days: 4)),
      weight: 54.8,
    ),
    HealthRecord(
      date: DateTime.now().subtract(const Duration(days: 3)),
      weight: 54.6,
    ),
    HealthRecord(
      date: DateTime.now().subtract(const Duration(days: 2)),
      weight: 54.5,
    ),
    HealthRecord(
      date: DateTime.now().subtract(const Duration(days: 1)),
      weight: 54.3,
    ),
    HealthRecord(
      date: DateTime.now(),
      weight: 54.2,
    ),
  ];
}

class HealthRecord {
  final DateTime date;
  final double? weight;
  final double? bodyFat;
  final int? steps;

  HealthRecord({
    required this.date,
    this.weight,
    this.bodyFat,
    this.steps,
  });
}
