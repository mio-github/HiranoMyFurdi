class Visit {
  final String id;
  final DateTime date;
  final String storeName;
  final String? checkInTime;
  final String? checkOutTime;
  final String? duration;

  Visit({
    required this.id,
    required this.date,
    required this.storeName,
    this.checkInTime,
    this.checkOutTime,
    this.duration,
  });

  String get dateLabel {
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final yesterday = today.subtract(const Duration(days: 1));
    final visitDay = DateTime(date.year, date.month, date.day);

    if (visitDay == today) {
      return '今日';
    } else if (visitDay == yesterday) {
      return '昨日';
    } else {
      return '${date.month}/${date.day}';
    }
  }

  static VisitSummary mockVisitSummary = VisitSummary(
    streakDays: 5,
    currentWeekVisits: 3,
    weeklyGoal: 4,
    lastVisit: DateTime.now().subtract(const Duration(days: 1, hours: 5, minutes: 30)),
    recommendedNextVisit: DateTime.now().add(const Duration(hours: 18)),
    monthlyVisits: 13,
    weeklyAverage: 3.2,
  );

  static List<Visit> mockVisits = [
    Visit(
      id: '1',
      date: DateTime.now(),
      storeName: '渋谷店',
      checkInTime: '18:30',
      checkOutTime: '19:45',
      duration: '1時間15分',
    ),
    Visit(
      id: '2',
      date: DateTime.now().subtract(const Duration(days: 1)),
      storeName: '渋谷店',
      checkInTime: '19:00',
      checkOutTime: '20:00',
      duration: '1時間',
    ),
    Visit(
      id: '3',
      date: DateTime.now().subtract(const Duration(days: 3)),
      storeName: '渋谷店',
      checkInTime: '18:00',
      checkOutTime: '19:20',
      duration: '1時間20分',
    ),
  ];
}

class VisitSummary {
  final int streakDays;
  final int currentWeekVisits;
  final int weeklyGoal;
  final DateTime lastVisit;
  final DateTime recommendedNextVisit;
  final int monthlyVisits;
  final double weeklyAverage;

  VisitSummary({
    required this.streakDays,
    required this.currentWeekVisits,
    required this.weeklyGoal,
    required this.lastVisit,
    required this.recommendedNextVisit,
    required this.monthlyVisits,
    required this.weeklyAverage,
  });

  double get weeklyProgress => currentWeekVisits / weeklyGoal;
  int get remainingVisits => weeklyGoal - currentWeekVisits;
}
