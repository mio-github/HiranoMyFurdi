class Exercise {
  final String id;
  final DateTime date;
  final String type;
  final int duration; // in minutes
  final String intensity; // 低・中・高
  final int? calories;

  Exercise({
    required this.id,
    required this.date,
    required this.type,
    required this.duration,
    required this.intensity,
    this.calories,
  });

  String get dateLabel {
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final yesterday = today.subtract(const Duration(days: 1));
    final exerciseDay = DateTime(date.year, date.month, date.day);

    if (exerciseDay == today) {
      return '今日 ${date.hour}:${date.minute.toString().padLeft(2, '0')}';
    } else if (exerciseDay == yesterday) {
      return '昨日 ${date.hour}:${date.minute.toString().padLeft(2, '0')}';
    } else {
      final diff = today.difference(exerciseDay).inDays;
      if (diff == 2) {
        return '一昨日 ${date.hour}:${date.minute.toString().padLeft(2, '0')}';
      }
      return '${date.month}/${date.day}';
    }
  }

  static List<Exercise> mockExercises = [
    Exercise(
      id: '1',
      date: DateTime.now().subtract(const Duration(hours: 5, minutes: 30)),
      type: 'AIマシン',
      duration: 45,
      intensity: '中',
      calories: 350,
    ),
    Exercise(
      id: '2',
      date: DateTime.now().subtract(const Duration(days: 1, hours: 5)),
      type: '動画トレーニング',
      duration: 30,
      intensity: '低',
      calories: 180,
    ),
    Exercise(
      id: '3',
      date: DateTime.now().subtract(const Duration(days: 2, hours: 6)),
      type: 'AIマシン',
      duration: 50,
      intensity: '高',
      calories: 420,
    ),
  ];

  static ExerciseSummary mockWeeklySummary = ExerciseSummary(
    totalMinutes: 245,
    totalCalories: 1250,
    workoutDays: [30, 45, 20, 50, 35, 40, 25],
  );
}

class ExerciseSummary {
  final int totalMinutes;
  final int totalCalories;
  final List<int> workoutDays; // minutes per day for the week

  ExerciseSummary({
    required this.totalMinutes,
    required this.totalCalories,
    required this.workoutDays,
  });
}
