class Store {
  final String id;
  final String name;
  final int currentOccupancy; // 現在の利用率 (0-100)
  final bool isFavorite;

  Store({
    required this.id,
    required this.name,
    required this.currentOccupancy,
    this.isFavorite = false,
  });

  String get occupancyStatus {
    if (currentOccupancy < 30) {
      return 'かなり空いています';
    } else if (currentOccupancy < 50) {
      return '空いています';
    } else if (currentOccupancy < 70) {
      return 'やや混雑しています';
    } else if (currentOccupancy < 90) {
      return '混雑しています';
    } else {
      return '大変混雑しています';
    }
  }

  String get occupancyColor {
    if (currentOccupancy < 30) {
      return 'green';
    } else if (currentOccupancy < 50) {
      return 'lightgreen';
    } else if (currentOccupancy < 70) {
      return 'yellow';
    } else if (currentOccupancy < 90) {
      return 'orange';
    } else {
      return 'red';
    }
  }

  static Store mockStore = Store(
    id: '1',
    name: '渋谷店',
    currentOccupancy: 25,
    isFavorite: true,
  );
}
