import 'package:flutter/material.dart';
import '../theme/app_colors.dart';

/// カスタムプログレスバー
class FurdiProgressBar extends StatelessWidget {
  final double progress; // 0.0 ~ 1.0
  final double height;
  final Color? backgroundColor;
  final Color? progressColor;

  const FurdiProgressBar({
    super.key,
    required this.progress,
    this.height = 8,
    this.backgroundColor,
    this.progressColor,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      height: height,
      decoration: BoxDecoration(
        color: backgroundColor ?? AppColors.gray50,
        borderRadius: BorderRadius.circular(height / 2),
      ),
      child: FractionallySizedBox(
        alignment: Alignment.centerLeft,
        widthFactor: progress.clamp(0.0, 1.0),
        child: Container(
          decoration: BoxDecoration(
            color: progressColor ?? AppColors.primaryPink,
            borderRadius: BorderRadius.circular(height / 2),
          ),
        ),
      ),
    );
  }
}
