import 'package:flutter/material.dart';

class ReportScreen extends StatefulWidget {
  const ReportScreen({super.key});

  @override
  State<ReportScreen> createState() => _ReportScreenState();
}

class _ReportScreenState extends State<ReportScreen> with SingleTickerProviderStateMixin {
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF5F5F5),
      appBar: AppBar(
        title: const Text('レポート'),
        backgroundColor: Colors.white,
        bottom: TabBar(
          controller: _tabController,
          labelColor: const Color(0xFFFF69B4),
          unselectedLabelColor: const Color(0xFF3A3A3C),
          indicatorColor: const Color(0xFFFF69B4),
          tabs: const [
            Tab(text: '運動記録'),
            Tab(text: '体組成'),
            Tab(text: '来館履歴'),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          _buildExerciseTab(),
          _buildBodyTab(),
          _buildVisitTab(),
        ],
      ),
    );
  }

  Widget _buildExerciseTab() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // 期間フィルター
          Row(
            children: [
              _buildFilterButton('週', true),
              const SizedBox(width: 8),
              _buildFilterButton('月', false),
              const SizedBox(width: 8),
              _buildFilterButton('年', false),
            ],
          ),
          const SizedBox(height: 16),

          // チャート
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: const Color(0xFFE5E5E7)),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'トレーニング時間（週）',
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                    color: Color(0xFF1C1C1E),
                  ),
                ),
                const SizedBox(height: 16),
                SizedBox(
                  height: 150,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      _buildBarChartColumn('月', 0.3),
                      _buildBarChartColumn('火', 0.45),
                      _buildBarChartColumn('水', 0.2),
                      _buildBarChartColumn('木', 0.5),
                      _buildBarChartColumn('金', 0.35),
                      _buildBarChartColumn('土', 0.4),
                      _buildBarChartColumn('日', 0.25),
                    ],
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),

          // サマリー
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: const Color(0xFFE5E5E7)),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  '今週のサマリー',
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                    color: Color(0xFF1C1C1E),
                  ),
                ),
                const SizedBox(height: 12),
                Row(
                  children: [
                    Expanded(
                      child: Container(
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: const Color(0xFFF5F5F5),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: const Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                Icon(Icons.access_time, size: 16, color: Color(0xFFFF69B4)),
                                SizedBox(width: 4),
                                Text(
                                  '総時間',
                                  style: TextStyle(fontSize: 12, color: Color(0xFF3A3A3C)),
                                ),
                              ],
                            ),
                            SizedBox(height: 4),
                            Text(
                              '245分',
                              style: TextStyle(
                                fontSize: 24,
                                fontWeight: FontWeight.bold,
                                color: Color(0xFF1C1C1E),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Container(
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: const Color(0xFFF5F5F5),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: const Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                Icon(Icons.local_fire_department, size: 16, color: Color(0xFFFF69B4)),
                                SizedBox(width: 4),
                                Text(
                                  '消費カロリー',
                                  style: TextStyle(fontSize: 12, color: Color(0xFF3A3A3C)),
                                ),
                              ],
                            ),
                            SizedBox(height: 4),
                            Text(
                              '1,250kcal',
                              style: TextStyle(
                                fontSize: 24,
                                fontWeight: FontWeight.bold,
                                color: Color(0xFF1C1C1E),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),

          // 運動リスト
          Container(
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: const Color(0xFFE5E5E7)),
            ),
            child: Column(
              children: [
                _buildExerciseListItem('AIマシン', '今日 18:30', '45分', '中'),
                const Divider(height: 1),
                _buildExerciseListItem('動画トレーニング', '昨日 19:00', '30分', '低'),
                const Divider(height: 1),
                _buildExerciseListItem('AIマシン', '一昨日 18:00', '50分', '高'),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBodyTab() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // 期間フィルター
          Row(
            children: [
              _buildFilterButton('週', true),
              const SizedBox(width: 8),
              _buildFilterButton('月', false),
              const SizedBox(width: 8),
              _buildFilterButton('年', false),
            ],
          ),
          const SizedBox(height: 16),

          // 体重グラフ
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: const Color(0xFFE5E5E7)),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  '体重推移（週）',
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                    color: Color(0xFF1C1C1E),
                  ),
                ),
                const SizedBox(height: 16),
                SizedBox(
                  height: 150,
                  child: CustomPaint(
                    size: const Size(double.infinity, 150),
                    painter: LineChartPainter(),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),

          // 現在の体重
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: const Color(0xFFE5E5E7)),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          '現在の体重',
                          style: TextStyle(fontSize: 12, color: Color(0xFF3A3A3C)),
                        ),
                        SizedBox(height: 4),
                        Text(
                          '54.2kg',
                          style: TextStyle(
                            fontSize: 32,
                            fontWeight: FontWeight.bold,
                            color: Color(0xFF1C1C1E),
                          ),
                        ),
                      ],
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                      decoration: BoxDecoration(
                        color: const Color(0xFF4CAF50).withValues(alpha: 0.1),
                        borderRadius: BorderRadius.circular(16),
                      ),
                      child: const Row(
                        children: [
                          Icon(Icons.trending_down, size: 16, color: Color(0xFF4CAF50)),
                          SizedBox(width: 4),
                          Text(
                            '-0.3kg',
                            style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                              color: Color(0xFF4CAF50),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                const Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    Column(
                      children: [
                        Text(
                          'BMI',
                          style: TextStyle(fontSize: 12, color: Color(0xFF3A3A3C)),
                        ),
                        SizedBox(height: 4),
                        Text(
                          '21.2',
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                            color: Color(0xFF1C1C1E),
                          ),
                        ),
                      ],
                    ),
                    Column(
                      children: [
                        Text(
                          '体脂肪率',
                          style: TextStyle(fontSize: 12, color: Color(0xFF3A3A3C)),
                        ),
                        SizedBox(height: 4),
                        Text(
                          '24.5%',
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                            color: Color(0xFF1C1C1E),
                          ),
                        ),
                      ],
                    ),
                    Column(
                      children: [
                        Text(
                          '筋肉量',
                          style: TextStyle(fontSize: 12, color: Color(0xFF3A3A3C)),
                        ),
                        SizedBox(height: 4),
                        Text(
                          '38.2kg',
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                            color: Color(0xFF1C1C1E),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildVisitTab() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // カレンダー
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: const Color(0xFFE5E5E7)),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      '2024年1月',
                      style: TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.bold,
                        color: Color(0xFF1C1C1E),
                      ),
                    ),
                    Icon(Icons.calendar_today, size: 20, color: Color(0xFF3A3A3C)),
                  ],
                ),
                const SizedBox(height: 16),
                // 曜日ヘッダー
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: ['日', '月', '火', '水', '木', '金', '土']
                      .map((day) => SizedBox(
                            width: 40,
                            child: Center(
                              child: Text(
                                day,
                                style: const TextStyle(
                                  fontSize: 12,
                                  color: Color(0xFF3A3A3C),
                                ),
                              ),
                            ),
                          ))
                      .toList(),
                ),
                const SizedBox(height: 8),
                // カレンダーグリッド（簡易版）
                ...List.generate(5, (week) {
                  return Padding(
                    padding: const EdgeInsets.symmetric(vertical: 4),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: List.generate(7, (day) {
                        final dayNumber = week * 7 + day + 1;
                        if (dayNumber > 31) return const SizedBox(width: 40);
                        final isVisited = [1, 3, 5, 8, 10, 12, 15, 17, 19, 22, 24, 26, 29].contains(dayNumber);
                        return Container(
                          width: 40,
                          height: 40,
                          decoration: BoxDecoration(
                            color: isVisited ? const Color(0xFFFF69B4) : Colors.transparent,
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: Center(
                            child: Text(
                              '$dayNumber',
                              style: TextStyle(
                                fontSize: 14,
                                color: isVisited ? Colors.white : const Color(0xFF1C1C1E),
                                fontWeight: isVisited ? FontWeight.bold : FontWeight.normal,
                              ),
                            ),
                          ),
                        );
                      }),
                    ),
                  );
                }),
              ],
            ),
          ),
          const SizedBox(height: 16),

          // 来館統計
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: const Color(0xFFE5E5E7)),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  '来館統計',
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                    color: Color(0xFF1C1C1E),
                  ),
                ),
                const SizedBox(height: 12),
                Row(
                  children: [
                    Expanded(
                      child: Container(
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: const Color(0xFFF5F5F5),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: const Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              '今月の来館',
                              style: TextStyle(fontSize: 12, color: Color(0xFF3A3A3C)),
                            ),
                            SizedBox(height: 4),
                            Text(
                              '13回',
                              style: TextStyle(
                                fontSize: 24,
                                fontWeight: FontWeight.bold,
                                color: Color(0xFF1C1C1E),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Container(
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: const Color(0xFFF5F5F5),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: const Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              '週平均',
                              style: TextStyle(fontSize: 12, color: Color(0xFF3A3A3C)),
                            ),
                            SizedBox(height: 4),
                            Text(
                              '3.2回',
                              style: TextStyle(
                                fontSize: 24,
                                fontWeight: FontWeight.bold,
                                color: Color(0xFF1C1C1E),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),

          // 最近の来館履歴
          Container(
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: const Color(0xFFE5E5E7)),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Padding(
                  padding: EdgeInsets.all(16),
                  child: Text(
                    '最近の来館履歴',
                    style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.bold,
                      color: Color(0xFF1C1C1E),
                    ),
                  ),
                ),
                const Divider(height: 1),
                _buildVisitListItem('今日', '18:30 - 19:45', '1時間15分', '渋谷店'),
                const Divider(height: 1),
                _buildVisitListItem('昨日', '19:00 - 20:00', '1時間', '渋谷店'),
                const Divider(height: 1),
                _buildVisitListItem('1/27', '18:00 - 19:20', '1時間20分', '渋谷店'),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildFilterButton(String label, bool isActive) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: isActive ? const Color(0xFFFF69B4) : Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: isActive ? const Color(0xFFFF69B4) : const Color(0xFFE5E5E7),
        ),
      ),
      child: Text(
        label,
        style: TextStyle(
          fontSize: 12,
          fontWeight: FontWeight.bold,
          color: isActive ? Colors.white : const Color(0xFF1C1C1E),
        ),
      ),
    );
  }

  Widget _buildBarChartColumn(String label, double heightRatio) {
    return Expanded(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.end,
        children: [
          Container(
            width: double.infinity,
            height: 120 * heightRatio,
            decoration: BoxDecoration(
              color: const Color(0xFFFF69B4),
              borderRadius: BorderRadius.circular(4),
            ),
          ),
          const SizedBox(height: 4),
          Text(
            label,
            style: const TextStyle(fontSize: 10, color: Color(0xFF3A3A3C)),
          ),
        ],
      ),
    );
  }

  Widget _buildExerciseListItem(String type, String date, String duration, String intensity) {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  type,
                  style: const TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                    color: Color(0xFF1C1C1E),
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  '$duration • 強度: $intensity',
                  style: const TextStyle(fontSize: 12, color: Color(0xFF3A3A3C)),
                ),
              ],
            ),
          ),
          Text(
            date,
            style: const TextStyle(fontSize: 12, color: Color(0xFF3A3A3C)),
          ),
        ],
      ),
    );
  }

  Widget _buildVisitListItem(String date, String time, String duration, String store) {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  date,
                  style: const TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                    color: Color(0xFF1C1C1E),
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  '$time • $duration',
                  style: const TextStyle(fontSize: 12, color: Color(0xFF3A3A3C)),
                ),
              ],
            ),
          ),
          Text(
            store,
            style: const TextStyle(fontSize: 12, color: Color(0xFF3A3A3C)),
          ),
        ],
      ),
    );
  }
}

// 折れ線グラフ用のカスタムペイン
class LineChartPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = const Color(0xFFFF69B4)
      ..strokeWidth = 3
      ..strokeCap = StrokeCap.round
      ..style = PaintingStyle.stroke;

    final points = [
      Offset(0, size.height * 0.6),
      Offset(size.width / 6, size.height * 0.5),
      Offset(size.width / 3, size.height * 0.45),
      Offset(size.width / 2, size.height * 0.4),
      Offset(size.width * 2 / 3, size.height * 0.35),
      Offset(size.width * 5 / 6, size.height * 0.32),
      Offset(size.width, size.height * 0.3),
    ];

    final path = Path();
    path.moveTo(points[0].dx, points[0].dy);
    for (var i = 1; i < points.length; i++) {
      path.lineTo(points[i].dx, points[i].dy);
    }

    canvas.drawPath(path, paint);

    // ポイントの円を描画
    final circlePaint = Paint()
      ..color = const Color(0xFFFF69B4)
      ..style = PaintingStyle.fill;

    for (final point in points) {
      canvas.drawCircle(point, 4, circlePaint);
    }

    // 曜日ラベル
    final textStyle = const TextStyle(
      fontSize: 10,
      color: Color(0xFF3A3A3C),
    );
    final days = ['月', '火', '水', '木', '金', '土', '日'];
    for (var i = 0; i < days.length; i++) {
      final textSpan = TextSpan(text: days[i], style: textStyle);
      final textPainter = TextPainter(
        text: textSpan,
        textDirection: TextDirection.ltr,
      );
      textPainter.layout();
      textPainter.paint(
        canvas,
        Offset(
          size.width * i / 6 - textPainter.width / 2,
          size.height - 15,
        ),
      );
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
