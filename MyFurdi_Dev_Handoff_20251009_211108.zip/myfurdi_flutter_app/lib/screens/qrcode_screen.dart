import 'package:flutter/material.dart';

class QRCodeScreen extends StatelessWidget {
  const QRCodeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF5F5F5),
      appBar: AppBar(
        title: const Text('入館証'),
        backgroundColor: Colors.white,
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: const Color(0xFFE5E5E7)),
              ),
              child: const Icon(
                Icons.qr_code_2,
                size: 200,
                color: Color(0xFF1C1C1E),
              ),
            ),
            const SizedBox(height: 16),
            const Text(
              '会員番号: 001',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
                color: Color(0xFF1C1C1E),
              ),
            ),
            const SizedBox(height: 8),
            const Text(
              'スタッフにご提示ください',
              style: TextStyle(
                fontSize: 14,
                color: Color(0xFF3A3A3C),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
