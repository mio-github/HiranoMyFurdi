import 'package:flutter/material.dart';

class MenuScreen extends StatelessWidget {
  const MenuScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF5F5F5),
      appBar: AppBar(
        title: const Text('メニュー'),
        backgroundColor: Colors.white,
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            // プロフィールカード
            Container(
              margin: const EdgeInsets.all(16),
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: const Color(0xFFE5E5E7)),
              ),
              child: Row(
                children: [
                  Container(
                    width: 60,
                    height: 60,
                    decoration: BoxDecoration(
                      color: const Color(0xFFFFE4E1),
                      borderRadius: BorderRadius.circular(30),
                    ),
                    child: const Icon(
                      Icons.person,
                      size: 30,
                      color: Color(0xFFFF69B4),
                    ),
                  ),
                  const SizedBox(width: 16),
                  const Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'FURDI会員様',
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                            color: Color(0xFF1C1C1E),
                          ),
                        ),
                        SizedBox(height: 4),
                        Text(
                          '会員番号: 001',
                          style: TextStyle(
                            fontSize: 14,
                            color: Color(0xFF3A3A3C),
                          ),
                        ),
                      ],
                    ),
                  ),
                  const Icon(
                    Icons.chevron_right,
                    color: Color(0xFF3A3A3C),
                  ),
                ],
              ),
            ),

            // メニューリスト
            Container(
              margin: const EdgeInsets.symmetric(horizontal: 16),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: const Color(0xFFE5E5E7)),
              ),
              child: Column(
                children: [
                  _buildMenuItem(Icons.science, '遺伝子テスト結果を見る', () {}),
                  const Divider(height: 1),
                  _buildMenuItem(Icons.person_outline, 'プロフィール編集', () {}),
                  const Divider(height: 1),
                  _buildMenuItem(Icons.store, '店舗情報', () {}),
                  const Divider(height: 1),
                  _buildMenuItem(Icons.calendar_today, '予約管理', () {}),
                ],
              ),
            ),
            const SizedBox(height: 16),

            // 設定セクション
            Container(
              margin: const EdgeInsets.symmetric(horizontal: 16),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: const Color(0xFFE5E5E7)),
              ),
              child: Column(
                children: [
                  _buildMenuItem(Icons.notifications_outlined, '通知設定', () {}),
                  const Divider(height: 1),
                  _buildMenuItem(Icons.lock_outline, 'プライバシー', () {}),
                  const Divider(height: 1),
                  _buildMenuItem(Icons.help_outline, 'ヘルプ・FAQ', () {}),
                  const Divider(height: 1),
                  _buildMenuItem(Icons.description_outlined, '利用規約', () {}),
                ],
              ),
            ),
            const SizedBox(height: 16),

            // その他
            Container(
              margin: const EdgeInsets.symmetric(horizontal: 16),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: const Color(0xFFE5E5E7)),
              ),
              child: Column(
                children: [
                  _buildMenuItem(Icons.info_outline, 'アプリについて', () {}),
                  const Divider(height: 1),
                  _buildMenuItem(Icons.logout, 'ログアウト', () {}, isDestructive: true),
                ],
              ),
            ),
            const SizedBox(height: 32),
          ],
        ),
      ),
    );
  }

  Widget _buildMenuItem(IconData icon, String title, VoidCallback onTap, {bool isDestructive = false}) {
    return InkWell(
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
        child: Row(
          children: [
            Icon(
              icon,
              color: isDestructive ? Colors.red : const Color(0xFF3A3A3C),
              size: 24,
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Text(
                title,
                style: TextStyle(
                  fontSize: 16,
                  color: isDestructive ? Colors.red : const Color(0xFF1C1C1E),
                ),
              ),
            ),
            Icon(
              Icons.chevron_right,
              color: isDestructive ? Colors.red : const Color(0xFF3A3A3C),
            ),
          ],
        ),
      ),
    );
  }
}
