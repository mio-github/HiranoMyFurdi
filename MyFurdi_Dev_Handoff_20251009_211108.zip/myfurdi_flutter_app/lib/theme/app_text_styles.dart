import 'package:flutter/material.dart';
import 'app_colors.dart';

/// MyFurdi アプリケーションテキストスタイル
/// design_tokens.jsonから生成
class AppTextStyles {
  AppTextStyles._();

  // Font Sizes
  static const double fontSizeXS = 9;
  static const double fontSizeSM = 11;
  static const double fontSizeBase = 12;
  static const double fontSizeMD = 13;
  static const double fontSizeLG = 14;
  static const double fontSizeXL = 16;
  static const double fontSize2XL = 18;
  static const double fontSize3XL = 24;
  static const double fontSize4XL = 28;

  // Font Weights
  static const FontWeight fontWeightRegular = FontWeight.w400;
  static const FontWeight fontWeightMedium = FontWeight.w500;
  static const FontWeight fontWeightSemibold = FontWeight.w600;
  static const FontWeight fontWeightBold = FontWeight.w700;

  // Heading Styles
  static const TextStyle headingLarge = TextStyle(
    fontSize: fontSize3XL,
    fontWeight: fontWeightBold,
    color: AppColors.gray900,
    height: 1.2,
  );

  static const TextStyle headingMedium = TextStyle(
    fontSize: fontSize2XL,
    fontWeight: fontWeightBold,
    color: AppColors.gray900,
    height: 1.2,
  );

  static const TextStyle headingSmall = TextStyle(
    fontSize: fontSizeXL,
    fontWeight: fontWeightBold,
    color: AppColors.gray900,
    height: 1.2,
  );

  // Body Text Styles
  static const TextStyle bodyLarge = TextStyle(
    fontSize: fontSizeXL,
    fontWeight: fontWeightRegular,
    color: AppColors.gray900,
    height: 1.5,
  );

  static const TextStyle bodyMedium = TextStyle(
    fontSize: fontSizeLG,
    fontWeight: fontWeightRegular,
    color: AppColors.gray900,
    height: 1.5,
  );

  static const TextStyle bodySmall = TextStyle(
    fontSize: fontSizeBase,
    fontWeight: fontWeightRegular,
    color: AppColors.gray900,
    height: 1.5,
  );

  // Caption / Label Styles
  static const TextStyle caption = TextStyle(
    fontSize: fontSizeSM,
    fontWeight: fontWeightRegular,
    color: AppColors.gray500,
    height: 1.5,
  );

  static const TextStyle labelSmall = TextStyle(
    fontSize: fontSizeXS,
    fontWeight: fontWeightRegular,
    color: AppColors.gray500,
    height: 1.5,
  );

  // Button Text Styles
  static const TextStyle buttonLarge = TextStyle(
    fontSize: fontSizeMD,
    fontWeight: fontWeightBold,
    color: AppColors.white,
    height: 1.2,
  );

  static const TextStyle buttonMedium = TextStyle(
    fontSize: fontSizeBase,
    fontWeight: fontWeightBold,
    color: AppColors.white,
    height: 1.2,
  );

  // Numeric Display
  static const TextStyle numberDisplay = TextStyle(
    fontSize: fontSize4XL,
    fontWeight: fontWeightBold,
    color: AppColors.gray900,
    height: 1.2,
  );

  // Tab Label
  static const TextStyle tabLabel = TextStyle(
    fontSize: fontSizeXS,
    fontWeight: fontWeightRegular,
    height: 1.2,
  );

  static const TextStyle tabLabelActive = TextStyle(
    fontSize: fontSizeXS,
    fontWeight: fontWeightBold,
    height: 1.2,
  );
}
