import 'package:flutter/material.dart';

/// MyFurdi アプリケーションカラーパレット
/// design_tokens.jsonから生成
class AppColors {
  AppColors._();

  // Primary Colors
  static const Color primaryPink = Color(0xFFFF69B4);
  static const Color primaryPinkLight = Color(0xFFFFE4E1);
  static const Color primaryPinkDark = Color(0xFFFF1493);

  // Neutral Colors
  static const Color white = Color(0xFFFFFFFF);
  static const Color gray50 = Color(0xFFF5F5F5);
  static const Color gray100 = Color(0xFFE5E5E7);
  static const Color gray500 = Color(0xFF3A3A3C);
  static const Color gray900 = Color(0xFF1C1C1E);
  static const Color black = Color(0xFF000000);

  // Semantic Colors
  static const Color success = Color(0xFF4CAF50);
  static const Color error = Color(0xFFFF0000);
  static const Color info = Color(0xFF2196F3);
  static const Color warning = Color(0xFFFF9800);

  // Gradient Colors
  static const LinearGradient primaryGradient = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [primaryPink, primaryPinkDark],
  );
}
