import 'package:flutter/material.dart';
import '../theme/app_colors.dart';
import '../theme/app_text_styles.dart';
import '../widgets/furdi_card.dart';
import '../widgets/furdi_button.dart';
import '../widgets/progress_bar.dart';
import '../models/user.dart';
import '../models/challenge.dart';
import '../models/visit.dart';
import '../models/health_data.dart';
import '../models/store.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final User user = User.mockUser;
  final List<Challenge> challenges = Challenge.mockDailyChallenges;
  final VisitSummary visitSummary = Visit.mockVisitSummary;
  final HealthData healthData = HealthData.mockHealthData;
  final Store store = Store.mockStore;

  int _selectedHealthTab = 0;

  String get greeting {
    final hour = DateTime.now().hour;
    if (hour < 12) {
      return 'おはようございます';
    } else if (hour < 18) {
      return 'こんにちは';
    } else {
      return 'こんばんは';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.gray50,
      appBar: AppBar(
        title: Text('$greeting、${user.name}さん！'),
        backgroundColor: AppColors.white,
        elevation: 0,
        actions: [
          Stack(
            children: [
              IconButton(
                icon: const Icon(Icons.notifications_outlined),
                onPressed: () {},
              ),
              Positioned(
                right: 12,
                top: 12,
                child: Container(
                  width: 8,
                  height: 8,
                  decoration: const BoxDecoration(
                    color: AppColors.primaryPink,
                    shape: BoxShape.circle,
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // 今日のチャレンジカード
              _buildTodayChallengeCard(),
              const SizedBox(height: 15),

              // 来店サマリーカード
              _buildVisitSummaryCard(),
              const SizedBox(height: 15),

              // 混雑状況カード
              _buildCongestionCard(),
              const SizedBox(height: 15),

              // 健康データカード
              _buildHealthDataCard(),
              const SizedBox(height: 15),

              // クイックアクション
              _buildQuickActions(),
              const SizedBox(height: 15),

              // 今週の成果
              _buildWeeklySummary(),
            ],
          ),
        ),
      ),
    );
  }

  // 今日のチャレンジカード
  Widget _buildTodayChallengeCard() {
    final completedCount = challenges.where((c) => c.isCompleted).length;
    final totalCount = challenges.length;
    final todayChallenge = challenges.firstWhere(
      (c) => !c.isCompleted && c.actionText != null,
      orElse: () => challenges.first,
    );

    return FurdiCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Text(
                '🎯 今日のチャレンジ',
                style: AppTextStyles.headingMedium,
              ),
              const Spacer(),
              Text(
                '$completedCount/$totalCount 達成',
                style: const TextStyle(
                  fontSize: 11,
                  fontWeight: FontWeight.bold,
                  color: AppColors.gray500,
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: AppColors.primaryPinkLight,
              borderRadius: BorderRadius.circular(8),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  todayChallenge.title,
                  style: const TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.w600,
                    color: AppColors.gray900,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  '報酬: ${todayChallenge.reward}',
                  style: const TextStyle(
                    fontSize: 11,
                    color: AppColors.primaryPink,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          if (todayChallenge.actionText != null)
            SizedBox(
              width: double.infinity,
              child: PrimaryButton(
                text: todayChallenge.actionText!,
                onPressed: () {},
              ),
            ),
          const SizedBox(height: 8),
          FurdiProgressBar(progress: completedCount / totalCount),
        ],
      ),
    );
  }

  // 来店サマリーカード
  Widget _buildVisitSummaryCard() {
    final lastVisitTime =
        '${visitSummary.lastVisit.hour}:${visitSummary.lastVisit.minute.toString().padLeft(2, '0')}';
    final recommendedTime =
        '${visitSummary.recommendedNextVisit.hour}:00頃';

    return FurdiCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            '🔥 ${visitSummary.streakDays}日連続来店中！',
            style: const TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
              color: AppColors.gray900,
            ),
          ),
          const SizedBox(height: 12),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text(
                '今週の来店',
                style: TextStyle(
                  fontSize: 12,
                  color: AppColors.gray500,
                ),
              ),
              Text(
                '${visitSummary.currentWeekVisits}/${visitSummary.weeklyGoal}回',
                style: const TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.bold,
                  color: AppColors.gray900,
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          FurdiProgressBar(progress: visitSummary.weeklyProgress),
          const SizedBox(height: 8),
          Text(
            'あと${visitSummary.remainingVisits}回で目標達成です！',
            style: const TextStyle(
              fontSize: 11,
              fontWeight: FontWeight.w600,
              color: AppColors.primaryPink,
            ),
          ),
          const SizedBox(height: 12),
          const Divider(height: 1),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      '前回来店',
                      style: TextStyle(
                        fontSize: 10,
                        color: AppColors.gray500,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      '昨日 $lastVisitTime',
                      style: const TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                        color: AppColors.gray900,
                      ),
                    ),
                  ],
                ),
              ),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      '次回おすすめ',
                      style: TextStyle(
                        fontSize: 10,
                        color: AppColors.gray500,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      '明日 $recommendedTime',
                      style: const TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                        color: AppColors.primaryPink,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  // 混雑状況カード
  Widget _buildCongestionCard() {
    Color statusColor;
    switch (store.occupancyColor) {
      case 'green':
        statusColor = AppColors.success;
        break;
      case 'lightgreen':
        statusColor = const Color(0xFF84CC16);
        break;
      case 'yellow':
        statusColor = const Color(0xFFF59E0B);
        break;
      case 'orange':
        statusColor = const Color(0xFFF97316);
        break;
      case 'red':
        statusColor = const Color(0xFFEF4444);
        break;
      default:
        statusColor = AppColors.success;
    }

    return FurdiCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            '📍 ${store.name}${store.isFavorite ? '（お気に入り）' : ''}',
            style: const TextStyle(
              fontSize: 12,
              color: AppColors.gray500,
            ),
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Container(
                width: 12,
                height: 12,
                decoration: BoxDecoration(
                  color: statusColor,
                  shape: BoxShape.circle,
                ),
              ),
              const SizedBox(width: 10),
              Text(
                store.occupancyStatus,
                style: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  color: AppColors.gray900,
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Text(
            '現在の利用率: ${store.currentOccupancy}%',
            style: const TextStyle(
              fontSize: 11,
              color: AppColors.gray500,
            ),
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: PrimaryButton(
                  text: '詳しく見る',
                  onPressed: () {},
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: SecondaryButton(
                  text: '今から行く',
                  onPressed: () {},
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  // 健康データカード
  Widget _buildHealthDataCard() {
    return FurdiCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // タブ
          Row(
            children: [
              _buildHealthTab('体重', 0),
              const SizedBox(width: 20),
              _buildHealthTab('体脂肪', 1),
              const SizedBox(width: 20),
              _buildHealthTab('歩数', 2),
            ],
          ),
          const SizedBox(height: 20),
          // 数値表示 (体重のみ実装)
          if (_selectedHealthTab == 0) ...[
            Row(
              crossAxisAlignment: CrossAxisAlignment.baseline,
              textBaseline: TextBaseline.alphabetic,
              children: [
                Text(
                  healthData.currentWeight.toStringAsFixed(1),
                  style: const TextStyle(
                    fontSize: 28,
                    fontWeight: FontWeight.bold,
                    color: AppColors.gray900,
                  ),
                ),
                const SizedBox(width: 4),
                const Text(
                  'kg',
                  style: TextStyle(
                    fontSize: 16,
                    color: AppColors.gray500,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                Icon(
                  healthData.isWeightDecreasing
                      ? Icons.trending_down
                      : Icons.trending_up,
                  size: 16,
                  color: AppColors.success,
                ),
                const SizedBox(width: 4),
                Text(
                  '${healthData.weightChange.toStringAsFixed(1)}kg（前回比）',
                  style: const TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.w600,
                    color: AppColors.success,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            const Text(
              '順調に減っています✨',
              style: TextStyle(
                fontSize: 13,
                fontWeight: FontWeight.w600,
                color: AppColors.success,
              ),
            ),
          ],
          if (_selectedHealthTab == 1) ...[
            Row(
              crossAxisAlignment: CrossAxisAlignment.baseline,
              textBaseline: TextBaseline.alphabetic,
              children: [
                Text(
                  healthData.bodyFatPercentage.toStringAsFixed(1),
                  style: const TextStyle(
                    fontSize: 28,
                    fontWeight: FontWeight.bold,
                    color: AppColors.gray900,
                  ),
                ),
                const SizedBox(width: 4),
                const Text(
                  '%',
                  style: TextStyle(
                    fontSize: 16,
                    color: AppColors.gray500,
                  ),
                ),
              ],
            ),
          ],
          if (_selectedHealthTab == 2) ...[
            const Row(
              crossAxisAlignment: CrossAxisAlignment.baseline,
              textBaseline: TextBaseline.alphabetic,
              children: [
                Text(
                  '8,453',
                  style: TextStyle(
                    fontSize: 28,
                    fontWeight: FontWeight.bold,
                    color: AppColors.gray900,
                  ),
                ),
                SizedBox(width: 4),
                Text(
                  '歩',
                  style: TextStyle(
                    fontSize: 16,
                    color: AppColors.gray500,
                  ),
                ),
              ],
            ),
          ],
          const SizedBox(height: 12),
          SizedBox(
            width: double.infinity,
            child: PrimaryButton(
              text: '記録する',
              onPressed: () {},
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHealthTab(String label, int index) {
    final isActive = _selectedHealthTab == index;
    return GestureDetector(
      onTap: () {
        setState(() {
          _selectedHealthTab = index;
        });
      },
      child: Column(
        children: [
          Text(
            label,
            style: TextStyle(
              fontSize: 13,
              fontWeight: isActive ? FontWeight.bold : FontWeight.normal,
              color: isActive ? AppColors.primaryPink : AppColors.gray500,
            ),
          ),
          const SizedBox(height: 4),
          if (isActive)
            Container(
              width: 30,
              height: 2,
              color: AppColors.primaryPink,
            ),
        ],
      ),
    );
  }

  // クイックアクション
  Widget _buildQuickActions() {
    return FurdiCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'クイックアクション',
            style: TextStyle(
              fontSize: 13,
              fontWeight: FontWeight.bold,
              color: AppColors.gray900,
            ),
          ),
          const SizedBox(height: 12),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              _buildQuickActionButton(Icons.play_circle_outline, '動画'),
              _buildQuickActionButton(Icons.edit_note, '記録'),
              _buildQuickActionButton(Icons.bar_chart, 'データ'),
            ],
          ),
          const SizedBox(height: 12),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              _buildQuickActionButton(Icons.notifications_outlined, 'お知らせ'),
              _buildQuickActionButton(Icons.help_outline, 'FAQ'),
              _buildQuickActionButton(Icons.biotech, '遺伝子'),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildQuickActionButton(IconData icon, String label) {
    return InkWell(
      onTap: () {},
      borderRadius: BorderRadius.circular(8),
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          children: [
            Container(
              width: 48,
              height: 48,
              decoration: BoxDecoration(
                color: AppColors.primaryPinkLight,
                borderRadius: BorderRadius.circular(24),
              ),
              child: Icon(
                icon,
                color: AppColors.primaryPink,
                size: 24,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              label,
              style: const TextStyle(
                fontSize: 11,
                fontWeight: FontWeight.w600,
                color: AppColors.gray900,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // 今週の成果
  Widget _buildWeeklySummary() {
    return FurdiCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Text(
                '📈 今週の成果',
                style: TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.bold,
                  color: AppColors.gray900,
                ),
              ),
              const Spacer(),
              Icon(
                Icons.chevron_right,
                size: 20,
                color: AppColors.gray500,
              ),
            ],
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      '時間',
                      style: TextStyle(
                        fontSize: 10,
                        color: AppColors.gray500,
                      ),
                    ),
                    const SizedBox(height: 4),
                    const Text(
                      '120分',
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        color: AppColors.gray900,
                      ),
                    ),
                    const SizedBox(height: 2),
                    const Text(
                      '+20分 ⬆️',
                      style: TextStyle(
                        fontSize: 10,
                        color: AppColors.success,
                      ),
                    ),
                  ],
                ),
              ),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: const [
                    Text(
                      'カロリー',
                      style: TextStyle(
                        fontSize: 10,
                        color: AppColors.gray500,
                      ),
                    ),
                    SizedBox(height: 4),
                    Text(
                      '850 kcal',
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        color: AppColors.gray900,
                      ),
                    ),
                  ],
                ),
              ),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      '来店',
                      style: TextStyle(
                        fontSize: 10,
                        color: AppColors.gray500,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      '${visitSummary.currentWeekVisits}回',
                      style: const TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        color: AppColors.gray900,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
