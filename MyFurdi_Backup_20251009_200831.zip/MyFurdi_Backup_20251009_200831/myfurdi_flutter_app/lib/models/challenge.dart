class Challenge {
  final String id;
  final String title;
  final String description;
  final String reward;
  final bool isCompleted;
  final String? actionText;

  Challenge({
    required this.id,
    required this.title,
    required this.description,
    required this.reward,
    this.isCompleted = false,
    this.actionText,
  });

  static List<Challenge> mockDailyChallenges = [
    Challenge(
      id: '1',
      title: 'アプリを開く',
      description: '',
      reward: 'デイリースタンプ 🎫',
      isCompleted: true,
    ),
    Challenge(
      id: '2',
      title: '体重を記録する',
      description: '',
      reward: 'ヘルスバッジ 🏅',
      isCompleted: true,
      actionText: '1タップで記録する',
    ),
    Challenge(
      id: '3',
      title: '混雑状況を確認する',
      description: '',
      reward: 'スマートバッジ 🔍',
      isCompleted: true,
    ),
    Challenge(
      id: '4',
      title: '動画を1本視聴する',
      description: '',
      reward: 'トレーナーバッジ 🎬',
      isCompleted: false,
      actionText: '視聴',
    ),
    Challenge(
      id: '5',
      title: '来店する',
      description: '',
      reward: 'フィットネスバッジ 💪',
      isCompleted: false,
    ),
  ];

  static List<WeeklyChallenge> mockWeeklyChallenges = [
    WeeklyChallenge(
      id: '1',
      title: '週3回来店チャレンジ',
      emoji: '🏃',
      current: 2,
      target: 3,
      reward: 'ウィークリーチャンピオン 🏆',
      daysLeft: 3,
      isCompleted: false,
    ),
    WeeklyChallenge(
      id: '2',
      title: '動画3本視聴チャレンジ',
      emoji: '🎬',
      current: 3,
      target: 3,
      reward: 'ビデオマスター 📺',
      daysLeft: 3,
      isCompleted: true,
    ),
  ];

  static List<MonthlyChallenge> mockMonthlyChallenges = [
    MonthlyChallenge(
      id: '1',
      title: '累計10時間トレーニング',
      emoji: '💪',
      current: 8.5,
      target: 10,
      reward: 'マンスリーアスリート 🥇',
      unit: '時間',
    ),
  ];
}

class WeeklyChallenge {
  final String id;
  final String title;
  final String emoji;
  final int current;
  final int target;
  final String reward;
  final int daysLeft;
  final bool isCompleted;

  WeeklyChallenge({
    required this.id,
    required this.title,
    required this.emoji,
    required this.current,
    required this.target,
    required this.reward,
    required this.daysLeft,
    this.isCompleted = false,
  });

  double get progress => current / target;
}

class MonthlyChallenge {
  final String id;
  final String title;
  final String emoji;
  final double current;
  final double target;
  final String reward;
  final String unit;

  MonthlyChallenge({
    required this.id,
    required this.title,
    required this.emoji,
    required this.current,
    required this.target,
    required this.reward,
    required this.unit,
  });

  double get progress => current / target;
  double get remaining => target - current;
}
