import 'package:flutter/material.dart';

class Badge {
  final String id;
  final String name;
  final String emoji;
  final bool isEarned;
  final String? progress; // e.g., "1/7" or "あと9日"
  final List<Color> gradientColors;

  Badge({
    required this.id,
    required this.name,
    required this.emoji,
    required this.isEarned,
    this.progress,
    required this.gradientColors,
  });

  static List<Badge> mockBadges = [
    Badge(
      id: '1',
      name: '初来店',
      emoji: '🏅',
      isEarned: true,
      progress: '1/1',
      gradientColors: [const Color(0xFFFBBF24), const Color(0xFFF97316)],
    ),
    Badge(
      id: '2',
      name: '7連続',
      emoji: '🔥',
      isEarned: true,
      progress: '1/7',
      gradientColors: [const Color(0xFFEF4444), const Color(0xFFEA580C)],
    ),
    Badge(
      id: '3',
      name: '10時間',
      emoji: '💪',
      isEarned: true,
      progress: '1/14',
      gradientColors: [const Color(0xFF3B82F6), const Color(0xFF9333EA)],
    ),
    Badge(
      id: '4',
      name: '-1kg',
      emoji: '📉',
      isEarned: true,
      progress: '1/20',
      gradientColors: [const Color(0xFF10B981), const Color(0xFF14B8A6)],
    ),
    Badge(
      id: '5',
      name: '14連続',
      emoji: '🔒',
      isEarned: false,
      progress: 'あと9日',
      gradientColors: [const Color(0xFF9CA3AF), const Color(0xFF6B7280)],
    ),
    Badge(
      id: '6',
      name: '50時間',
      emoji: '🔒',
      isEarned: false,
      progress: 'あと42h',
      gradientColors: [const Color(0xFF9CA3AF), const Color(0xFF6B7280)],
    ),
    Badge(
      id: '7',
      name: '-3kg',
      emoji: '🔒',
      isEarned: false,
      progress: 'あと2.6kg',
      gradientColors: [const Color(0xFF9CA3AF), const Color(0xFF6B7280)],
    ),
    Badge(
      id: '8',
      name: '???',
      emoji: '？',
      isEarned: false,
      progress: 'シークレット',
      gradientColors: [const Color(0xFF9CA3AF), const Color(0xFF6B7280)],
    ),
  ];
}
